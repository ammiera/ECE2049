#ifndef HELPERS_H_
#define HELPERS_H_

#include <msp430.h>

/* Peripherals.c and .h are where the functions that implement
 * the LEDs and keypad, etc are. It is often useful to organize
 * your code by putting like functions together in files.
 * You include the header associated with that file(s)
 * into the main file of your project. */
#include "peripherals.h"

void display_message(char* message);

#endif /* HELPERS_H_ */
